# Milestone 1: Criteria & Data Collection

Privacy and data practices of 8 apps (WhatsApp, Instagram, Spotify, Zoom, TikTok, Telegram, Notion, Duolingo), scored on 8 criteria from policies and documentation.

## Structure
- `data/criteria.csv`: criterion definitions and 0/1/2 scoring rules
- `data/app_scores.csv`: one row per app and criterion (score, evidence paraphrase, source URL, source type, date accessed)
- `notebooks/analysis.ipynb`: validation, summary tables and chart
- `report/Milestone1_Summary.pdf`: short summary of data and steps

## Notes
- `NV` = not verified in the collection pass; excluded from totals, not counted as 0.
- `source_type`: `primary` = company domain, `secondary` = third-party analysis. Secondary rows should be confirmed against the original policy.
- Date accessed: 2026-11-11.

## Run
```
pip install pandas matplotlib jupyter
jupyter notebook notebooks/analysis.ipynb
```
